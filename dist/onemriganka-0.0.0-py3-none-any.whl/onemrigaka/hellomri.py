def hello(name):
    print(f"hello {name} ")